
import { initializeApp } from "firebase/app";
const firebaseConfig = {
    apiKey: "AIzaSyBgSuJfKC_n1MFniaabECKRYPIXR8TXKgY",
    authDomain: "agent-6ea8d.firebaseapp.com",
    projectId: "agent-6ea8d",
    storageBucket: "agent-6ea8d.appspot.com",
    messagingSenderId: "646107823266",
    appId: "1:646107823266:web:f3c338c1434bbb0965abfb",
    measurementId: "G-3QVFK2NV03",
};

const firebaseApp = initializeApp(firebaseConfig);

export default firebaseApp;
