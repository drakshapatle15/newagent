// login/FillNumber.jsx


import React from 'react'
import PhoneInput from "react-phone-input-2";
import ExternalLogin from './ExternalLogin';

function FillNumber(props) {
    
    const handleSubmit = props.handleSubmit;
    const ph = props.ph
    const setPh = props.setPh


    return (
        <main className="flex flex-col items-center justify-center ">
            <div className="w-full max-w-md">
               
                <div id="recaptcha-container"></div>
                <form action="">
                    <PhoneInput
                        country={"in"}
                        value={ph}
                        onChange={setPh}
                        inputStyle={{ height: "50px", width: "90%", padding: "0.75rem", marginLeft: "2rem" }} // Added marginLeft

                        countryCodeEditable={false}
                    />
                    <button
                        type="submit"
                        onClick={handleSubmit}
                        // onClick={onSignInSubmit}
                        className="mt-4 w-full bg-emerald-500  text-white px-4 py-2 rounded-md font-bold hover:bg-blue-700 focus:outline-none focus:ring focus:ring-blue-300"
                    >
                        Continue
                    </button>
                </form>

                <div className="mt-4 text-center">
                    <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold mr-2">
                        OR
                    </span>
                </div>
                <div className="flex flex-col  flex justify-center mt-4">
                    <ExternalLogin />
                </div>
            </div>
        </main>
    )
}

export default FillNumber
