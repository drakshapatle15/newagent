// import React, { useState } from "react";

// const EditProfile = () => {
//   const [fullName, setFullName] = useState("");
//   const [email, setEmail] = useState("");
//   const [phone, setPhone] = useState("");
//   const [address, setAddress] = useState("");
//   const [city, setCity] = useState("");
//   const [stateProvince, setStateProvince] = useState("");
//   const [zipCode, setZipCode] = useState("");
//   const [country, setCountry] = useState("");

//   const handleSave = () => {
//     // Add your save logic here
//     console.log("Saving profile...");
//   };

//   const handleCancel = () => {
//     // Add your cancel logic here
//     console.log("Canceling edit...");
//   };

//   return (
//     <div className="flex justify-center items-center h-screen">
//       <div className="bg-white p-8 shadow-md rounded-md w-full md:w-2/3 lg:w-1/2 xl:w-1/3">
//         <h1 className="text-2xl font-semibold mb-4">Edit Profile</h1>

//         {/* Profile Image and Change Photo */}
//         <div className="flex items-center mb-4">
//           <div className="w-16 h-16 bg-gray-300 rounded-full mr-4"></div>
//           <button className="text-blue-500 hover:underline">
//             Change Photo
//           </button>
//           <span className="text-red-500 ml-2">Delete</span>
//         </div>

//         {/* Form Rows */}
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
//           {/* First Row */}
//           <div className="flex items-center">
//             <label className="w-1/3">Full Name</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={fullName}
//               onChange={(e) => setFullName(e.target.value)}
//             />
//           </div>
//           {/* ... Similar structure for Email and Phone */}
//           <div className="flex items-center">
//             <label className="w-1/3">Emailr</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={fullName}
//               onChange={(e) => setFullName(e.target.value)}
//             />
//           </div>

//           <div className="flex items-center">
//             <label className="w-1/3">Contact no</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={fullName}
//               onChange={(e) => setFullName(e.target.value)}
//             />
//           </div>
//           {/* Second Row */}
//           <div className="flex items-center">
//             <label className="w-1/3">Address</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={address}
//               onChange={(e) => setAddress(e.target.value)}
//             />
//           </div>

//           <div className="flex items-center">
//             <label className="w-1/3">City</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={fullName}
//               onChange={(e) => setFullName(e.target.value)}
//             />
//           </div>
//           {/* ... Similar structure for City */}

//           {/* Third Row */}
//           <div className="flex items-center">
//             <label className="w-1/3">State/Province</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={stateProvince}
//               onChange={(e) => setStateProvince(e.target.value)}
//             />
//           </div>
//           <div className="flex items-center">
//             <label className="w-1/3">Zip Postal Code</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={stateProvince}
//               onChange={(e) => setStateProvince(e.target.value)}
//             />
//           </div>
//           <div className="flex items-center">
//             <label className="w-1/3">Country</label>
//             <input
//               type="text"
//               className="flex-1 border border-gray-300 p-2 rounded"
//               value={stateProvince}
//               onChange={(e) => setStateProvince(e.target.value)}
//             />
//           </div>
//           {/* ... Similar structure for Zip Code and Country Dropdown */}
//         </div>

//         {/* Save and Cancel Buttons */}
//         <div className="flex justify-end">
//           <button
//             className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 mr-2"
//             onClick={handleSave}
//           >
//             Save
//           </button>
//           <button
//             className="bg-gray-500 text-white py-2 px-4 rounded hover:bg-gray-600"
//             onClick={handleCancel}
//           >
//             Cancel
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default EditProfile;

import "tailwindcss/tailwind.css";
import React, { useState, useEffect } from "react";

import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { FaUserCircle, FaTrash } from "react-icons/fa";

const EditProfile = () => {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [ph, setPh] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [zipcode, setZipcode] = useState("");
  const [country, setCountry] = useState("");
  const [countryList, setCountryList] = useState([]);

  useEffect(() => {
    // Fetch country list when the component mounts
    fetch("http://localhost:4200/common/country/list", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        page_number: 1,
        records_per_page: "100000",
        sort_field: "name",
        sort_order: "ASC",
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 200) {
          setCountryList(data.payload.data);
        } else {
          console.error("Failed to fetch country list");
        }
      })
      .catch((error) => {
        console.error("Error fetching country list:", error);
      });
  }, []);

  return (
    <div className="max-w-5xl mt-20 mx-auto justify-between align-items-center p-8 bg-white rounded shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <FaUserCircle className="text-4xl mr-2" />
          <span className="text-2xl font-bold">Edit Profile</span>
        </div>
        <div className="flex items-center">
          <button className="text-blue-500 mr-2">Change Password</button>
          <FaTrash className="text-red-500" />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        <InputWithLabel
          label="Full Name"
          value={fullName}
          onChange={setFullName}
        />
        <InputWithLabel
          label="Full Name"
          value={fullName}
          onChange={setFullName}
        />
        <InputWithLabel label="Email" value={email} onChange={setEmail} />
        <PhoneInput
          containerStyle={{marginLeft:"20px", marginTop: "10px" }}
          inputStyle={{ height: "55px"}}
          country={"in"}
          value={ph}
          onChange={setPh}
          countryCodeEditable={false}
        />

      
          <InputWithLabel
            label="Address"
            value={address}
            onChange={setAddress}
          />
        
        <InputWithLabel label="City" value={city} onChange={setCity} />
          <InputWithLabel label="State" value={state} onChange={setState} />
          <InputWithLabel label="ZipCode" value={zipcode} onChange={setZipcode} /> 
           <CountryDropdown value={country} onChange={setCountry} countryList={countryList} />
        
      </div>

      <div className="flex justify-end mt-4">
        <button className="mr-2 px-4 py-2 bg-gray-300 text-gray-700 rounded">
          Cancel
        </button>
        <button className="px-4 py-2 bg-emerald-500 text-white rounded">
          Save
        </button>
      </div>
    </div>
  );
};

const InputWithLabel = ({ label, value, onChange }) => {
  const [isTyping, setIsTyping] = useState(false);

  const handleInputChange = (e) => {
    onChange(e.target.value);
    setIsTyping(!!e.target.value);
  };

  return (
    <div
      className={"input-container mb-4 "}
    >
      <label className={`placeholder ${isTyping ? "small" : ""} text-gray-500`}>
        {label}
      </label>
      <input
        type="text"
        value={value}
        onChange={handleInputChange}
        className="w-full p-7 border border-gray-300 rounded h-10"
      />
    </div>
  );
};

const CountryDropdown = ({ value, onChange, countryList }) => {
  return (
    <div className={`input-container mb-4 flex-grow`}>
      <label className={`placeholder ${value ? "small" : ""} text-gray-500`}>
        Country
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-7 border border-gray-300 rounded h-10"
        style={{
          marginTop: "0",
          marginBottom: "0",
          maxHeight: "150px",
          overflowY: "auto",
        }}
      >
        <option value="">Select Country</option>
        {countryList.map((country) => (
          <option key={country.id} value={country.short_name}>
            {country.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default EditProfile;
