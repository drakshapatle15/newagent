import React from "react";

const Mainpage = () => {
  return (
    <div>
      <h1 className="text-2xl">Dashboard</h1>
    </div>
  );
};

export default Mainpage;
