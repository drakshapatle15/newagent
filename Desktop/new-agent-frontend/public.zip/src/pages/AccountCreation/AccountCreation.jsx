
import "tailwindcss/tailwind.css";
import React, { useState,useEffect} from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const InputWithLabel = ({ label, value, onChange }) => {
  const [isTyping, setIsTyping] = useState(false);

  const handleInputChange = (e) => {
    onChange(e.target.value);
    setIsTyping(!!e.target.value);
  };

  return (
    <div className={`input-container mb-4 ${label === "ZipCode"|| label === "State"|| label === "Country"||label === "City" ? "flex-grow" : ""}`}>
      <label className={`placeholder ${isTyping ? "small" : ""} text-gray-500`}>{label}</label>
      <input type="text" value={value} onChange={handleInputChange} className="w-full p-7 border border-gray-300 rounded h-10 " />
    </div>
  );
};
const CountryDropdown = ({ value, onChange, countryList }) => {
  return (
    <div className={`input-container mb-4 flex-grow`}>
      <label className={`placeholder ${value ? "small" : ""} text-gray-500`}>Country</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-7 border border-gray-300 rounded h-10"
        style={{ marginTop: '0', marginBottom: '0', maxHeight: '150px', overflowY: 'auto' }}
      >
        <option value="">Select Country</option>
        {countryList.map((country) => (
          <option key={country.id} value={country.short_name}>
            {country.name}
          </option>
        ))}
      </select>
    </div>
  );
};

const App = () => {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [lastName, setLastName] = useState("");
  const [address, setAddress] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [zipcode, setZipcode] = useState("");
  const [country, setCountry] = useState("");
  const [ph, setPh] = useState("");

  const [countryList, setCountryList] = useState([]);

  useEffect(() => {
    // Fetch country list when the component mounts
    fetch("http://localhost:4200/common/country/list", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        page_number: 1,
        records_per_page: "100000",
        sort_field: "name",
        sort_order: "ASC",
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === 200) {
          setCountryList(data.payload.data);
        } else {
          console.error("Failed to fetch country list");
        }
      })
      .catch((error) => {
        console.error("Error fetching country list:", error);
      });
  }, [useEffect]); // Empty dependency array to fetch the list only once when the component mounts

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded shadow-lg">
      <div className="text-center mb-6">
        <h1 className="text-4xl font-bold mb-2">Account Info </h1>
        <p className= "text-xl font-semibold text-gray-500">Let's get  started! Creating an Account creating  </p>
      </div>

      <InputWithLabel label="Full Name" value={fullName} onChange={setFullName}  className="text-gray-500"/>
      <InputWithLabel label="Last Name" value={lastName} onChange={setLastName} />
      <InputWithLabel label="Email" value={email} onChange={setEmail} />
     

<PhoneInput
          containerStyle={{ marginTop: '10px' , marginLeft:'17px' ,marginRight:'17px'}} // Adjust the margin to your preference
          dropdownStyle={{ height: '250px' }}
          inputStyle={{ height: "55px", width: "90%", padding: "0.75rem", marginLeft: "2rem"  }} // Added marginLeft
          country={"in"}
          value={ph}
          onChange={setPh}
          countryCodeEditable={false}
        />
      <InputWithLabel label="Address" value={address} onChange={setAddress} />

      <div className="flex gap-6 mb-4">
        <InputWithLabel label="State" value={state} onChange={setState} />
        <InputWithLabel label="City" value={city} onChange={setCity} />
      </div>

      <div className="flex gap-4 mb-4">
        <InputWithLabel label="ZipCode" value={zipcode} onChange={setZipcode} />
        <CountryDropdown
        value={country}
        onChange={setCountry}
        countryList={countryList}
      />
        {/* <InputWithLabel label="Country" value={country} onChange={setCountry} /> */}
      </div>

      <div className="mb-4 flex items-center">
        <input type="checkbox" className="form-checkbox h-6 w-6 ml-4 bg-gray-500" />
        <span className="ml-2 text-sm">By Creating an Account you are agreeng our Term and Policy</span>
      </div>

      <div className="text-center">
        <button className="mt-4 w-full bg-emerald-500  text-white px-4 py-2 rounded-md font-bold hover:bg-blue-700 focus:outline-none focus:ring focus:ring-blue-300">Submit</button>
      </div>
    </div>
  );
};

export default App;

