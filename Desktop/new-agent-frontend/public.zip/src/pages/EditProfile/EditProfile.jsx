import React, { useState } from "react";

const EditProfile = () => {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [stateProvince, setStateProvince] = useState("");
  const [zipCode, setZipCode] = useState("");
  const [country, setCountry] = useState("");

  const handleSave = () => {
    // Add your save logic here
    console.log("Saving profile...");
  };

  const handleCancel = () => {
    // Add your cancel logic here
    console.log("Canceling edit...");
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <div className="bg-white p-8 shadow-md rounded-md w-full md:w-2/3 lg:w-1/2 xl:w-1/3">
        <h1 className="text-2xl font-semibold mb-4">Edit Profile</h1>

        {/* Profile Image and Change Photo */}
        <div className="flex items-center mb-4">
          <div className="w-16 h-16 bg-gray-300 rounded-full mr-4"></div>
          <button className="text-blue-500 hover:underline">
            Change Photo
          </button>
          <span className="text-red-500 ml-2">Delete</span>
        </div>

        {/* Form Rows */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          {/* First Row */}
          <div className="flex items-center">
            <label className="w-1/3">Full Name</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>
          {/* ... Similar structure for Email and Phone */}
          <div className="flex items-center">
            <label className="w-1/3">Emailr</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>

          <div className="flex items-center">
            <label className="w-1/3">Contact no</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>
          {/* Second Row */}
          <div className="flex items-center">
            <label className="w-1/3">Address</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
          </div>

          <div className="flex items-center">
            <label className="w-1/3">City</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
            />
          </div>
          {/* ... Similar structure for City */}

          {/* Third Row */}
          <div className="flex items-center">
            <label className="w-1/3">State/Province</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={stateProvince}
              onChange={(e) => setStateProvince(e.target.value)}
            />
          </div>
          <div className="flex items-center">
            <label className="w-1/3">Zip Postal Code</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={stateProvince}
              onChange={(e) => setStateProvince(e.target.value)}
            />
          </div>
          <div className="flex items-center">
            <label className="w-1/3">Country</label>
            <input
              type="text"
              className="flex-1 border border-gray-300 p-2 rounded"
              value={stateProvince}
              onChange={(e) => setStateProvince(e.target.value)}
            />
          </div>
          {/* ... Similar structure for Zip Code and Country Dropdown */}
        </div>

        {/* Save and Cancel Buttons */}
        <div className="flex justify-end">
          <button
            className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 mr-2"
            onClick={handleSave}
          >
            Save
          </button>
          <button
            className="bg-gray-500 text-white py-2 px-4 rounded hover:bg-gray-600"
            onClick={handleCancel}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditProfile;
