// // components/Signup.js

// import React, { useState } from "react";
// import axios from "axios";

// const Signup = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const handleSignup = async () => {
//     try {
//       const response = await axios.post("/api/signup", { email, password });
//       // Handle successful signup, e.g., redirect to login page
//     } catch (error) {
//       // Handle signup error
//       console.error("Signup failed", error);
//     }
//   };

//   return (
//     <div>
//       <h2>Signup</h2>
//       <input
//         type="email"
//         placeholder="Email"
//         onChange={(e) => setEmail(e.target.value)}
//       />
//       <input
//         type="password"
//         placeholder="Password"
//         onChange={(e) => setPassword(e.target.value)}
//       />
//       <button onClick={handleSignup}>Signup</button>
//     </div>
//   );
// };

// export default Signup;

// components/Signup.js

import React, { useState } from "react";
import axios from "axios";

const Signup = () => {
  const [first_name, setFirstname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [last_name, setLastname] = useState("");

  const handleSignup = async () => {
    try {
      const response = await axios.post("http://localhost:4100/auth/register", {
        first_name,
        last_name,
        email,
        password,
      });
      // Handle successful signup, e.g., redirect to login page
    } catch (error) {
      // Handle signup error
      console.error("Signup failed", error);
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Signup</h2>
      <input
        style={styles.input}
        type="first_name"
        placeholder="First Name"
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        style={styles.input}
        type="last_name"
        placeholder="Last Name"
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        style={styles.input}
        type="email"
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
      />

      <input
        style={styles.input}
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />
      <button style={styles.button} onClick={handleSignup}>
        Signup
      </button>
    </div>
  );
};

const styles = {
  container: {
    width: "100%",
    maxWidth: "400px",
    margin: "auto",
    padding: "20px",
  },
  title: {
    fontSize: "24px",
    marginBottom: "20px",
    textAlign: "center",
  },
  input: {
    width: "100%",
    padding: "10px",
    marginBottom: "10px",
    boxSizing: "border-box",
  },
  button: {
    width: "100%",
    padding: "10px",
    backgroundColor: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};

export default Signup;
